package wikihomesteps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import wikihomepages.wikihomepages;
import wikihomepages.wikiLanguageHomePage;


public class wikilanguagesteps {

    WebDriver driver = null;
    wikihomepages wikihome;
    wikiLanguageHomePage languageHomePage;

    public static String wikihomeurl = "https://en.wikipedia.org/wiki/Main_Page";

    @Given("Brower open succesfully with wikihome page")
    public void brower_open_succesfully_with_wikihome_page() throws Throwable{

        String projectpath = System.getProperty("user.dir") + "/src/test/resources/drivers/chromedriver.exe";
        System.out.println("Wikipedia project path is:"+ projectpath);

        System.setProperty("webDriver.chrome.driver", projectpath);

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        Thread.sleep(2000);
        System.out.println("Browser have opened successfully");
        driver.navigate().to(wikihomeurl);
    }
    @When("user enters <Language> in search field")
    public void user_enters_mandarin_chinese_in_search_field(String language) throws Throwable {

        wikihome = new wikihomepages(driver);

        wikihome.enterLanguage(language);
        Thread.sleep(3000);
        System.out.println("User entered language:"+ language);

    }
    @And("user clicks on search icon")
    public void user_clicks_search_icon() throws Throwable{

        wikihome.clickSearchButton();
        System.out.println("User hits enter key");
        Thread.sleep(3000);
    }
    @Then("user navigates to language home")
    public void user_navigates_to_language_home(String language) throws Throwable{
       languageHomePage = new wikiLanguageHomePage(driver);
       languageHomePage.LanguageHeader(language);
        Thread.sleep(3000);
        driver.close();
        driver.quit();
    }

}
