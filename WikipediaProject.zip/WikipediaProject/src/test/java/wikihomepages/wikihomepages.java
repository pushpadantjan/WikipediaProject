package wikihomepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class wikihomepages {

    protected WebDriver driver;
    static WebElement element;
    private By wikiHomePage_txt_searchBox = By.name("search");
    private By wikiHomePage_btn_searchButton = By.id("searchButton");
    private By wikiHomePage_lbl_Header = By.id("firstHeading");

    public wikihomepages(WebDriver driver) throws IllegalAccessException {
        this.driver = driver;
    }

    public void enterLanguage(String language) {
       driver.findElement(wikiHomePage_txt_searchBox).sendKeys(language);
    }
    public void clickSearchButton(){
        driver.findElement(wikiHomePage_btn_searchButton).click();
    }

}
