package wikihomepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class wikiLanguageHomePage {

    WebDriver driver;
    @FindBy(id = "firstHeading")
    WebElement languageHomePage;

    WebElement celebrityDOB = driver.findElement(By.xpath("(//td[@class=\"infobox-data\"])[1]"));
    WebElement celebrityspouse = driver.findElement(By.xpath("(//td[@class=\"infobox-data\"])[4]"));


    public wikiLanguageHomePage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, wikiLanguageHomePage.class);
    }

    public void LanguageHeader(String language) throws Throwable{
        languageHomePage.isDisplayed();
        driver.findElement(By.xpath("//h1[contains(text(),'"+language+"')]"));
    }

    public void CelebrityHeader(String celebrity_name) throws Throwable{
        languageHomePage.isDisplayed();
        driver.findElement(By.xpath("//h1[contains(text(),'"+celebrity_name+"')]"));
    }

    public void CelebrityDOB(String celebrity_name) throws Throwable{
        celebrityDOB.isDisplayed();
        String dob = celebrityDOB.getText();
        System.out.println(celebrity_name+" date of birth details:"+ dob);
    }

    public void CelebritySpouse(String celebrity_name) throws Throwable{
        celebrityspouse.isDisplayed();
        String spouse = celebrityspouse.getText();
        System.out.println(celebrity_name+" spouse details:"+ spouse);
    }
}
